<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Unit;
use App\Models\VendorProduct;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\DataTables;

class VendorProductController extends Controller
{
    public function listData(){
        $target = VendorProduct::where('created_by', auth()->user()->id)->get('id');
        $info = Product::whereNotIn('id', $target)->get();
        return response()->json([
            'data' => $info
        ], 200);
    }
    public function show($id){
        $target = VendorProduct::find($id);
        return response()->json([
            'data' => $target
        ], 200);
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = VendorProduct::with('stock_details','product_details','product_details.category_details','product_details.brand_details','product_details.unit_details','vendor')->where('created_by', auth::user()->id)->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('photo', function ($row) {
                    return '<img style="width: 50px" src="storage/product/' . $row->product_details->photo . '">';
                })
                ->addColumn('name', function ($row) {
                    return $row->product_details->name;
                })
                ->addColumn('vendor', function ($row) {
                    return $row->vendor->name;
                })
                ->addColumn('unit', function ($row) {
                    return $row->product_details->unit_details->name;
                })
                ->addColumn('category', function ($row) {
                    return $row->product_details->category_details->title;
                })->addColumn('brand', function ($row) {
                    return $row->product_details->brand_details->title;
                })
                ->addColumn('stock', function ($row) {
                    return $row->stock_details->sum('qty');
                })->addColumn('action', function ($row) {
                    $btn = '<button class="btn btn-primary btn-sm" onclick="AddStock('.$row->id.')"><i class="fab fa-buffer"></i></button>
                            <button class="btn btn-warning btn-sm" onclick="EditModal('.$row->id.')"><i class="fas fa-edit"></i></button>
                ';

                    return $btn;
                })
                ->rawColumns(['unit', 'photo','vendor','category','brand','stock', 'action'])
                ->make(true);
        }
        return view('admin.pages.vendor.product.index');
    }

    public function store(Request $request)
    {
       $st = VendorProduct::create([
            'product' => $request->products,
            'vendor_price' => $request->vendor_price,
            'sell_price' => $request->sell_price,
            'point' => $request->sell_price - $request->vendor_price,
            'created_by' =>  auth()->user()->id
        ]);
       if ($st){
           Stock::create([
               'vendor_product' =>$st->id,
               'created_by' => auth()->user()->id,
               'qty' =>  $request->qty
           ]);
       }

        return response()->json([
            'data' => $st,
            'message' => 'Product Added'
        ], 200);
    }
    public function price(Request $request)
    {
       $st = VendorProduct::where('id', $request->id)->update([
            'vendor_price' => $request->vendor_price,
            'sell_price' => $request->sell_price,
            'point' => $request->sell_price - $request->vendor_price,
        ]);

        return response()->json([
            'data' => $st,
            'message' => 'Product price Update'
        ], 200);
    }
    public function stock(Request $request)
    {
     $st = Stock::create([
            'vendor_product' => $request->id,
            'created_by' => auth()->user()->id,
            'qty' =>  $request->qty
        ]);

        return response()->json([
            'data' => $st,
            'message' => 'Stock Added'
        ], 200);
    }
    public function pedit($id){
        $target = VendorProduct::find($id);
        return response()->json([
           'data' => $target,
            'message' => 'Product Price Updated'
        ], 200);
    }
    public function pdestroy($id){
        $target = VendorProduct::destroy($id);
        return response()->json([
           'data' => $target,
            'message' => 'Product Deleted'
        ], 200);
    }
}
