<div class="mobile-menu"><a href="{{url('/')}}" title="Home Page"><i class="fas fa-home"></i><span>Home</span></a>
{{--    <button class="cate-btn" title="Category List"><i class="fas fa-list"></i><span>category</span></button>
    <button class="cart-btn" title="Cartlist"><i class="fas fa-shopping-basket"></i><span>cartlist</span><sup>9+</sup>
    </button>
    <a href="wishlist.html" title="Wishlist"><i class="fas fa-heart"></i><span>wishlist</span><sup>0</sup></a><a
        href="compare.html" title="Compare List"><i class="fas fa-random"></i><span>compare</span><sup>0</sup></a>--}}
</div>
