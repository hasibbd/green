<?php

const CONST_ROLE_ADMIN = 1;
const CONST_ROLE_USER = 0;
const CONST_ROLE_VENDOR = 2;
const CONST_STATUS_ENABLED = 1;
const CONST_STATUS_DISABLED = 0;



