<aside class="cart-sidebar">
    <div class="cart-header">
        <div class="cart-total"><i class="fas fa-shopping-basket"></i><span>total item <span class="t_cart_item">0</span></span></div>
        <button class="cart-close"><i class="icofont-close"></i></button>
    </div>
    <ul class="cart-list">

    </ul>
    <div class="cart-footer">
      {{--  <button class="coupon-btn">Do you have a coupon code?</button>
        <form class="coupon-form"><input type="text" placeholder="Enter your coupon code">
            <button type="submit"><span>apply</span></button>
        </form>--}}
        <a class="cart-checkout-btn" href="{{url('check-out')}}">
            <span class="checkout-label">Proceed to Checkout</span>
            <span class="checkout-price "></span>
            <span class="checkout-point "></span>
        </a>
    </div>
</aside>
