@include('user.partial.header')
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    @yield('content')
    <!-- /.content-wrapper -->

</div>
<!-- ./wrapper -->
@include('user.partial.script')
</body>
</html>
