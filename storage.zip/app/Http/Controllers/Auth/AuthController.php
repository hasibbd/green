<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function checkRef(Request $request){
        $check = User::where('user_id', $request->user_id)->get();
        if (count($check) > 0){
            if ($check->is_store_manager == 1){
                if ($check->is_registered){
                    return response()->json([
                        'message' => 'User Found',
                        'data' => $check
                    ],200);
                }else{
                    return response()->json([
                        'message' => 'User is not a registered user',
                        'data' => $check
                    ],404);
                }
            }else{
                return response()->json([
                    'message' => 'User is not a store manager',
                    'data' => $check
                ],404);
            }
        }else{
            return response()->json([
                'message' => 'Not Found'
            ],404);
        }
    }
    public function login(){
       return view('auth.pages.login');
    }
    public function registration(){
        return view('auth.pages.register');
    }
    public function forgot(){
        return view('auth.pages.forgot');
    }
    public function recover($token){
        $target = User::where('remember_token',$token)->first();
        return view('auth.pages.recover',compact('target'));
    }
    public function logout(){
        session()->flush();
        Auth::logout();
        return redirect()->route('/')->withErrors(['msg'=>'<div class="alert alert-primary" id="alert">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong>Thank You! </strong> See you soon...
                        </div>']);
    }
}
