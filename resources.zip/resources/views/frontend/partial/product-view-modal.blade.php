<div class="modal fade" id="product-view">
    <div class="modal-dialog">
        <div class="modal-content">
            <button class="modal-close icofont-close" data-bs-dismiss="modal"></button>
            <div class="product-view">
                <div class="row">
                    <div class="col-md-6 col-lg-6">
                        <div class="view-gallery">
                            <div class="view-label-group">{{--<label class="view-label new">new</label><label
                                    class="view-label off">-10%</label>--}}</div>
                            <ul class="preview-slider slider-arrow">
                                <li class="picZoomer">
                                    <img id="pr_image" src="{{asset('frontend/images/product/01.jpg')}}" alt="product">
                                </li>
                                {{-- <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                 <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                 <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                 <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                 <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                 <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>--}}
                            </ul>
                            <ul class="thumb-slider">
                                {{--              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>
                                              <li><img src="{{asset('frontend/images/product/01.jpg')}}" alt="product"></li>--}}
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                        <div class="view-details"><h3 class="view-name"><a href="product-video.html">existing product
                                    name</a></h3>
                            <div class="view-meta"><p>Vendor:<span id="pr_vendor">1234567</span></p>
                                <p>BRAND:<a href="#" id="pr_brand">radhuni</a></p></div>
                            <div class="view-rating">
                                {{--     <i class="active icofont-star"></i>
                                     <i class="active icofont-star"></i>
                                     <i class="active icofont-star"></i>
                                     <i class="active icofont-star"></i>
                                     <i class="icofont-star"></i>
                                     <a href="product-video.html">(3 reviews)</a>--}}
                            </div>
                            <h3 class="view-price">
                                {{-- <del>$38.00</del>--}}
                                <span id="pr_price">$24.00</span><span><small>/per <span id="pr_unit"></span></small></span></h3>
                            <p class="view-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit non tempora
                                magni repudiandae sint suscipit tempore quis maxime explicabo veniam eos reprehenderit
                                fuga</p>
                            {{--<div class="view-list-group"><label class="view-list-title">tags:</label>
                                <ul class="view-tag-list">
                                    <li><a href="#">organic</a></li>
                                    <li><a href="#">vegetable</a></li>
                                    <li><a href="#">chilis</a></li>
                                </ul>
                            </div>
                            <div class="view-list-group"><label class="view-list-title">Share:</label>
                                <ul class="view-share-list">
                                    <li><a href="#" class="icofont-facebook" title="Facebook"></a></li>
                                    <li><a href="#" class="icofont-twitter" title="Twitter"></a></li>
                                    <li><a href="#" class="icofont-linkedin" title="Linkedin"></a></li>
                                    <li><a href="#" class="icofont-instagram" title="Instagram"></a></li>
                                </ul>
                            </div>--}}
                            <div class="view-add-group">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
