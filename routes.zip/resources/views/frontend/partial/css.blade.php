<link rel="stylesheet" href="{{asset('frontend/fonts/flaticon/flaticon.css')}}">
<link rel="stylesheet" href="{{asset('frontend/fonts/icofont/icofont.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/fonts/fontawesome/fontawesome.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/vendor/venobox/venobox.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/vendor/slickslider/slick.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/vendor/niceselect/nice-select.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/vendor/bootstrap/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/main.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/index.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/checkout.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/wallet.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/profile.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/user-auth.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/blog-details.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/blog-grid.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/invoice.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/orderlist.css')}}">
<!-- Data Table -->
{{--    <link rel="stylesheet" href="{{asset('back/plugin/dudatepicker/duDatepicker.css')}}">--}}
<link rel="stylesheet" href="{{asset('plugins/dt/datatables/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('custom/front/css/custom.css')}}">

<!--Toaster-->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
