
@include('auth.partial.header')
<body class="hold-transition login-page">
<div class="login-box">
@yield('content')
</div>
@include('auth.partial.script')
</body>
</html>
